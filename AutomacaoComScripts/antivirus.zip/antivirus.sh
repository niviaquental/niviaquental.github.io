#!/bin/bash
echo File  "$1" scanned